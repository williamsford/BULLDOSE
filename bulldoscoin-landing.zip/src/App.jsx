import React from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function BulldosCoinLanding() {
  return (
    <main className="bg-black text-white min-h-screen font-sans">
      /* full component is already shown above in the canvas */
    </main>
  );
}
